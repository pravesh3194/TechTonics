package pages;

import java.io.IOException;
import java.sql.Date;
import java.sql.SQLData;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dbutils.Dao;
import pojo.Event;


public class Admin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
 
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		String topic=request.getParameter("topic");
		Dao dao=new Dao();
		try {
			Boolean result=dao.deleteEvent(topic);
			if(result==false)
			{
				response.sendRedirect("Admin.jsp");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
